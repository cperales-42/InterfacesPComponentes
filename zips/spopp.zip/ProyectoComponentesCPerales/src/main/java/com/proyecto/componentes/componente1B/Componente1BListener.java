/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.proyecto.componentes.componente1B;

/**
 *
 * @author Meu
 */
public interface Componente1BListener {
    public void enterPress(Componente1BObject evo);
    public void focusLost(Componente1BObject evo);
}
