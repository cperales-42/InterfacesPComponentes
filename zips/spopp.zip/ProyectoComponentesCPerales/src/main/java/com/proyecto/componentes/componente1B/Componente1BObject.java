/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.proyecto.componentes.componente1B;

import java.util.EventObject;

/**
 *
 * @author Meu
 */
public class Componente1BObject extends EventObject{
    
    public Componente1BObject(Object source) {
        super(source);
    }
}
