/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.proyecto.componentes.componente2B;

import java.util.EventListener;

/**
 *
 * @author Meu
 */
public interface Componente2BListener extends EventListener{
    void onItemSelected(Componente2BObject event);
}
