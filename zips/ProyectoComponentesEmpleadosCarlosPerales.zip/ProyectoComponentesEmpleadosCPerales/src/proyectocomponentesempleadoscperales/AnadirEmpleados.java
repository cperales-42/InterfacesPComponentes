/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectocomponentesempleadoscperales;

import com.proyecto.componentes.componente2B.Componente2BListener;
import com.proyecto.componentes.componente2B.Componente2BObject;
import com.proyecto.componentes.componente3.Componente3Listener;
import com.proyecto.componentes.componente3.Componente3Object;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import static proyectocomponentesempleadoscperales.ModificarEmpleados.obtenerCiudades;
import static proyectocomponentesempleadoscperales.ModificarEmpleados.obtenerPaises;

/**
 *
 * @author Meu
 */
public class AnadirEmpleados extends javax.swing.JFrame {

    /**
     * Creates new form AnadirEmpleados
     */
    
    private Connection con = null;
    public AnadirEmpleados() {
        initComponents();
    }
    
    public AnadirEmpleados(Connection con){
        initComponents(); // Carga los elementos visuales
        
        this.con = con;
        Object[][] paises;
        Object[][] ciudades;
        // Configurar etiquetas de Componente1B
       componente1B1.setjLabelText("Nombre:");
       componente1B1.setIsMandatory(true);
       componente1B1.setIsUp(true);
       componente1B1.inicializar();

       componente1B2.setjLabelText("Apellido:");
       componente1B2.setIsMandatory(true);
       componente1B2.setIsUp(true);
       componente1B2.inicializar();


        // Configurar etiquetas de Componente2B
        componente2B1.setJLabelText("País:");
        componente2B2.setJLabelText("Ciudad:");

        try {
            paises = obtenerPaises(con);
            componente2B1.cargarDatos(paises);
        } catch (SQLException e){
            e.printStackTrace();
        }
        
         componente2B1.addComponente2BListener(new Componente2BListener() {
        @Override
        public void onItemSelected(Componente2BObject evento) {
            try {
                // Obtener el código del país seleccionado
                int codPais = Integer.parseInt(evento.getCodigo());

                // Obtener las ciudades desde la base de datos
                Object[][] ciudades = obtenerCiudades(con, codPais);

                // Cargar las ciudades en el segundo componente
                componente2B2.setTieneMensaje(false); // Opcional: quitar mensaje
                componente2B2.setMatrizDatos(ciudades);

            } catch (Exception e) {
                e.printStackTrace();
                // También puedes mostrar un JOptionPane de error si lo deseas
            }
        }
    });
        // Configurar componente3 (por ejemplo, con los cargos disponibles)
        componente31.setJLabelText("Cargo:");

        Object[][] matrizCargos = obtenerCargosDesdeBD(con);
        componente31.setMatrizDatos(matrizCargos);

        // Listener de búsqueda (opcional, si quieres hacer filtro activo)
        componente31.addComponente3Listener(new Componente3Listener() {
            @Override
            public void onBusquedaRealizada(Componente3Object evento) {
                String texto = evento.getTextoBusqueda().toLowerCase();
                ArrayList<Object[]> filtrado = new ArrayList<>();
                for (Object[] fila : matrizCargos) {
                    if (fila[1].toString().toLowerCase().contains(texto)) {
                        filtrado.add(fila);
                    }
                }
                componente31.setMatrizDatos(filtrado.toArray(new Object[0][0]));
            }
        });
    }
    
    public static Object[][] obtenerPaises(Connection con) throws SQLException {
        String sql = "SELECT codigo, nombre FROM paises";

        try (PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
             ResultSet rs = ps.executeQuery()) {

            // 1. Contar filas
            rs.last();
            int numFilas = rs.getRow();
            rs.beforeFirst(); // Volver al inicio

            Object[][] datos = new Object[numFilas][2];

            // 2. Llenar datos
            int fila = 0;
            while (rs.next()) {
                datos[fila][0] = rs.getObject("codigo");
                datos[fila][1] = rs.getObject("nombre");
                fila++;
            }

            return datos;
        }
    }
    
    public static Object[][] obtenerCiudades(Connection con, int codPais) throws SQLException {
    String sql = "SELECT codigo, nombre FROM Ciudades WHERE codPais = ?";

    try (PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)) {
        ps.setInt(1, codPais);
        try (ResultSet rs = ps.executeQuery()) {

            // Contar filas
            rs.last();
            int numFilas = rs.getRow();
            rs.beforeFirst();

            Object[][] datos = new Object[numFilas][2];
            int fila = 0;

            while (rs.next()) {
                datos[fila][0] = rs.getObject("codigo");
                datos[fila][1] = rs.getObject("nombre");
                fila++;
            }

            return datos;
        }
    }
}
    private Object[][] obtenerCargosDesdeBD(Connection con) {
    ArrayList<Object[]> lista = new ArrayList<>();
    String sql = "SELECT codigo, nombre FROM cargos";
    try (PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            lista.add(new Object[]{rs.getInt("codigo"), rs.getString("nombre")});
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return lista.toArray(new Object[0][0]);
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        componente2B2 = new com.proyecto.componentes.componente2B.Componente2B();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        componente1B1 = new com.proyecto.componentes.componente1B.Componente1B();
        jLabel1 = new javax.swing.JLabel();
        componente1B2 = new com.proyecto.componentes.componente1B.Componente1B();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        componente31 = new com.proyecto.componentes.componente3.Componente3();
        jLabel2 = new javax.swing.JLabel();
        componente2B1 = new com.proyecto.componentes.componente2B.Componente2B();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        componente2B2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton1.setText("Guardar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Reiniciar");

        jLabel1.setText("VISOR EVENTOS");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("AÑADIR EMPLEADO");

        componente2B1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jButton1)
                        .addGap(59, 59, 59)
                        .addComponent(jButton2))
                    .addComponent(jLabel1)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(componente2B1, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(componente2B2, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(componente31, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(componente1B2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE)
                        .addComponent(componente1B1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(27, 27, 27)
                .addComponent(componente1B1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(componente1B2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(componente31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(componente2B1, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(componente2B2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(30, 30, 30)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jMenu1.setText("Archivo");

        jMenuItem1.setText("Buscar empleado");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Añadir empleado");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Funciones");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(50, 50, 50))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(106, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        BuscarEmpleados bp = new BuscarEmpleados();
        bp.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        AnadirEmpleados ae = new AnadirEmpleados();
        ae.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String nombre = componente1B1.getjTextField1Text().trim();
        String apellido = componente1B2.getjTextField1Text().trim();

        if (nombre.isEmpty() || apellido.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nombre y Apellido son obligatorios.", "Campos requeridos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String codCiudad = componente2B2.getCodigoSeleccionado();
        String codCargo = componente31.getCodigoSeleccionado();

        if (codCiudad == null || codCargo == null) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar Ciudad y Cargo.", "Datos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO Empleados (nombre, apellidos, codCargo, codCiudad) VALUES (?, ?, ?, ?)")) {

            ps.setString(1, nombre);
            ps.setString(2, apellido);
            ps.setInt(3, Integer.parseInt(codCargo));
            ps.setInt(4, Integer.parseInt(codCiudad));

            int filas = ps.executeUpdate();

            if (filas > 0) {
                JOptionPane.showMessageDialog(this, "Empleado guardado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo guardar el empleado.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al guardar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AnadirEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AnadirEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AnadirEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AnadirEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AnadirEmpleados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.proyecto.componentes.componente1B.Componente1B componente1B1;
    private com.proyecto.componentes.componente1B.Componente1B componente1B2;
    private com.proyecto.componentes.componente2B.Componente2B componente2B1;
    private com.proyecto.componentes.componente2B.Componente2B componente2B2;
    private com.proyecto.componentes.componente3.Componente3 componente31;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
