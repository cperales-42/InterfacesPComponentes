/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.proyecto.componentes.componente3;

import java.util.EventListener;

/**
 *
 * @author Meu
 */
public interface Componente3Listener extends EventListener{
    void onBusquedaRealizada(Componente3Object event);
}
