/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.proyecto.componentes.componente2B;

import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author Meu
 */
public class Componente2B extends javax.swing.JPanel {

    /**
     * Creates new form Componente2B
     */
    private Object[][] matrizDatos;
    private boolean tieneMensaje;
    private String mensaje;
    private final DefaultListModel<String> listModel;
    private final ArrayList<Componente2BListener> listeners = new ArrayList<>();
    
    public Componente2B() {
        initComponents();

    listModel = new DefaultListModel<>();
    jList1.setModel(listModel);

    Object[][] datos = {
        {"Afganistán"}, {"Albania"}, {"Alemania"}, {"Andorra"}, {"Angola"}, {"Antigua y Barbuda"}, {"Arabia Saudita"},
        {"Argelia"}, {"Argentina"}, {"Armenia"}, {"Australia"}, {"Austria"}, {"Azerbaiyán"}, {"Bahamas"}, {"Bangladés"},
        {"Barbados"}, {"Baréin"}, {"Bélgica"}, {"Belice"}, {"Benín"}, {"Bielorrusia"}, {"Birmania"}, {"Bolivia"},
        {"Bosnia y Herzegovina"}, {"Botsuana"}, {"Brasil"}, {"Brunéi"}, {"Bulgaria"}, {"Burkina Faso"}, {"Burundi"},
        {"Bután"}, {"Cabo Verde"}, {"Camboya"}, {"Camerún"}, {"Canadá"}, {"Catar"}, {"Chad"}, {"Chile"}, {"China"},
        {"Chipre"}, {"Colombia"}, {"Comoras"}, {"Corea del Norte"}, {"Corea del Sur"}, {"Costa de Marfil"},
        {"Costa Rica"}, {"Croacia"}, {"Cuba"}, {"Dinamarca"}, {"Dominica"}, {"Ecuador"}, {"Egipto"}, {"El Salvador"},
        {"Emiratos Árabes Unidos"}, {"Eritrea"}, {"Eslovaquia"}, {"Eslovenia"}, {"España"}, {"Estados Unidos"},
        {"Estonia"}, {"Esuatini"}, {"Etiopía"}, {"Filipinas"}, {"Finlandia"}, {"Fiyi"}, {"Francia"}, {"Gabón"},
        {"Gambia"}, {"Georgia"}, {"Ghana"}, {"Granada"}, {"Grecia"}, {"Guatemala"}, {"Guinea"}, {"Guinea-Bisáu"},
        {"Guinea Ecuatorial"}, {"Guyana"}, {"Haití"}, {"Honduras"}, {"Hungría"}, {"India"}, {"Indonesia"}, {"Irak"},
        {"Irán"}, {"Irlanda"}, {"Islandia"}, {"Islas Marshall"}, {"Israel"}, {"Italia"}, {"Jamaica"}, {"Japón"},
        {"Jordania"}, {"Kazajistán"}, {"Kenia"}, {"Kirguistán"}, {"Kiribati"}, {"Kuwait"}, {"Laos"}, {"Lesoto"},
        {"Letonia"}, {"Líbano"}, {"Liberia"}, {"Libia"}
    };

    matrizDatos = datos;
    mensaje = "Seleccione un país";
    tieneMensaje = true;

    cargarDatos(matrizDatos);

    jList1.addListSelectionListener(e -> {
        if (!e.getValueIsAdjusting()) {
            notificarItemSeleccionado();
        }
    });
    }
    
    // Métodos para gestionar oyentes
    public void addComponente2BListener(Componente2BListener listener) {
        listeners.add(listener);
    }

    public void removeComponente2BListener(Componente2BListener listener) {
        listeners.remove(listener);
    }
    
    private void notificarItemSeleccionado() {
        int indice = jList1.getSelectedIndex();

        if (indice == -1 || (tieneMensaje && indice == 0)) {
            return; // No hay selección válida
        }

        String codigo;
        if (tieneMensaje) {
            codigo = matrizDatos[indice - 1][0].toString(); // Si tiene mensaje, ajusta el índice
        } else {
            codigo = matrizDatos[indice][0].toString(); // Si no tiene mensaje, usa el índice directamente
        }

        String texto = jList1.getSelectedValue();

        // Crea el evento con la información obtenida
        Componente2BObject evento = new Componente2BObject(this, codigo, texto, indice, tieneMensaje);

        // Notifica a los listeners registrados
        for (Componente2BListener listener : listeners) {
            listener.onItemSelected(evento);
        }
    }
    
    public void setMatrizDatos(Object[][] matrizDatos){
        this.matrizDatos = matrizDatos;
        cargarDatos(matrizDatos);
    }
    public void setTieneMensaje(boolean tieneMensaje){
        this.tieneMensaje = tieneMensaje;
        cargarDatos(matrizDatos);
    }
    public void setMensaje(String mensaje){
        this.mensaje = mensaje;
        if (tieneMensaje) {
            cargarDatos(matrizDatos);
        }
    }
    
    public void setIndiceSeleccionado(int indice){
        if (indice >= 0 && indice < listModel.size()) {
            jList1.setSelectedIndex(indice);
        notificarItemSeleccionado();
        }
        else{
            System.out.println("Indice no valido");
        }
    }
    //getters
    public Object[][] getMatrizDatos(){
        return (matrizDatos);
    }
    public boolean getTieneMensaje(){
        return (tieneMensaje);
    }
    public String getMensaje(){
        return (mensaje);
    }
    public int getIndiceSeleccionado(){
        return (jList1.getSelectedIndex());
    }
    //metodos
    public void setJLabelText(String text){
        jLabel1.setText(text);
    }
    
    public String getCodigoSeleccionado() {
        int indice = jList1.getSelectedIndex();

        if (indice == -1) {
            return null; // No hay selección válida
        }

        if (tieneMensaje && indice == 0) {
            return null; // Si el primer elemento es un mensaje, no es un dato válido
        }

        // Ajustar el índice si hay mensaje
        if (tieneMensaje) {
            indice = indice - 1;
        }
        return matrizDatos[indice][0].toString();
    }
    
    public final void cargarDatos(Object[][] datos) {
        listModel.clear(); // Limpiar lista antes de actualizar

        if (tieneMensaje) {
            listModel.addElement(mensaje);
        }

        // Asignar matrizDatos correctamente
        this.matrizDatos = datos;

        for (int i = 0; i < datos.length; i++) {
            if (datos[i] != null && datos[i].length > 1 && datos[i][1] != null) {
                listModel.addElement(datos[i][1].toString()); // Mostrar columna 1 (nombre visible)
            }
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();

        setLayout(new java.awt.GridLayout(1, 0));

        jLabel1.setText("jLabel1");
        jLabel1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        add(jLabel1);

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        add(jScrollPane1);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JList<String> jList1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
